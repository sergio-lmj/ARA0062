<?php

include_once ("../servico/Bd.php");

$titulo = $_GET["titulo"];
$corpo = $_GET["corpo"];

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $sql = "update blog set titulo='$titulo',  corpo='$corpo' where id='$id' ";
}else {
    $sql = "INSERT INTO `blog` (`id`, `titulo`, `corpo`) VALUES (NULL, '$titulo', '$corpo')";    
}


$bd = new Bd();
$contador = $bd->exec($sql); // insert, update e delete

echo "<h1> $contador Cadastro efetuado com sucesso </h1>";

echo "<a href='consultablogUsuario.php'>Ver lista de cadastros </a><br><br><br><br>";


echo "<a href='https://slmj.000webhostapp.com/trabalhohtml/petshop.php'>Voltar ao Pratagy PetShop</a>";

?>