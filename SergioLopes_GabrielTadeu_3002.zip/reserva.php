<html>
    <head>
        <title>Hotel Pratagy</title>
        <style>

        </style>
        <script>

        </script>
    </head>
    <body>
        <h1> Reserva PETSHOP Pratagy</h1>

        <?php
             $dia=$_GET [ "dia" ] ;
             $mentra=$_GET [ "mentra" ] ;
             $porte=$_GET [ "porte" ] ;
             $horario=$_GET [ "horario" ] ;
             $nome=$_GET [ "nome" ] ;

            echo "<p>Dia do banho tosa: $dia</p>";
            echo "<p>Mês: $mentra</p>";
            echo "<p>Porte do cão: $porte</p>";
            echo "<p>Manhã/Tarde: $horario</p>";
            echo "<p>Nome: $nome</p>";
        ?>
    </body>
</html>