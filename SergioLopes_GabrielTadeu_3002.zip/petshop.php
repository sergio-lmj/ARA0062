<!doctype html>
<html>
      <head>
  		<meta charset="utf-8">
		<title> Pratagy Petshop </title>
	    <style>
	       #amarelo{background-color:#8c8691;font color:#ffffff}
	        #cinza{background-color:#34a4eb;}
	        h1{background-color:#34a4eb;}
	        h2{background-color:#34a4eb;}
	        h3{background-color:#34a4eb;}
	        h4{font:#ffffff;}
	        h5{background-color:#34a4eb;}
	        background-color:#8c8691;
	        
	    </style>
	    
	    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
	          
	  </head>
 
<body>
	  <section id="cinza">
	 <div class="container-fluid">
      <table class="table">
  
    <tr>
      <th scope="col"><h5>(21) 99999 3344 //</h5></th>
      <th scope="col"><h5> (21) 99999 7373 //</h5></th>
      <th scope="col"><h5> email:pratagypetshop@hotmail.com</h5></th>
    </tr>
    </table>
	 </div>
	  </section>
	
	
    <div class="container-fluid">
    <div class="card">
  <div class="card-body">
    <h1 class="card-title">Pratagy PetShop</h1>
    <p class="card-text"></p>
    <p class="card-text"><small class="text-muted"></small></p>
  </div>
  <img src="https://i.pinimg.com/originals/d8/dc/1f/d8dc1f2260b0edcbf6bace9aca42cf86.png" class="card-img-bottom" alt="...">
    </div>
    </div>
        
    <div class="container">
    <div class="row">
    <div class="col"> <a href='login.html'>Login</a></div>
    <div class="col"> <a href='#tosa'>Tosa e Banho</a></div>
    <div class="col"> <a href='#agenda'>Agendamento</a></div>
    <div class="col"> <a href='#produtos'>Produtos</a></div>
    <div class="col"> <a href='https://slmj.000webhostapp.com/trabalhohtml/usuario/incluirUsuario.php'>Cadastro</a></div>
    </div>
    
    
    
		
	<hr><hr>	
    <div class="card bg-dark text-white">
  <img src="https://i.pinimg.com/originals/9c/e0/74/9ce0744ddd2ad0b69f66cfe2cb1001ea.png" class="card-img" alt="...">
  <div class="card-img-overlay">
    <h5 class="card-title"></h5>
    <h4 class="card-text">Só quem é apaixonado por animais sabe: a relação de amor e cumplicidade que temos com nossos bichinhos de estimação é um vínculo único! Por essa razão, não medimos esforços para oferecer o que há de melhor para trazer ainda mais alegria e qualidade de vida. Rações, acessórios, medicamentos e brinquedos estão na nossa listinha de prioridades; e tudo isso você encontra em nosso Pet Shop online.</h4>
    <p class="card-text"></p>
  </div>
</div>
    
    <hr><hr>
        
<div class="container">        
        
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
       <div class="carousel-inner">
       <div class="carousel-item active">
         <img src="https://i.pinimg.com/originals/b7/cd/98/b7cd9897c5802c97f53034a9536b7428.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
          <img src="https://tipomanaus.com.br/wp-content/uploads/2019/01/Loja-de-Pet-Shop3285.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
         <img src="https://3.bp.blogspot.com/-MMSF4xW0QOk/Wl06Dv-YsNI/AAAAAAAANs4/7T9Zf2CWHAMsln9GNwLwIna5XvQl3PHcACLcBGAs/s640/arquitetar-arquitetura-de-varejo-012-ar-mar-pet-shop.jpg" class="d-block w-100" alt="...">
    </div>
    
    
    
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
 
        
     <hr><hr>   
       
       <div class="row">
        <div class="card" style="width: 18rem;">
            
  <img src="https://statig1.akamaized.net/bancodeimagens/9e/rs/2e/9ers2eqlpcmaaaon028oemwzf.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kit Mordida</h5>
    <p class="card-text">R$ 35,99</p>
    <a href="#" class="btn btn-primary">Adicionar ao carrinho</a>
        </div>
       </div>
       <a name="produtos"></a>
       <div class="card" style="width: 18rem;">
          
  <img src="https://static1.patasdacasa.com.br/articles/1/11/01/@/5156-os-brinquedos-para-cachorro-sao-uma-alte-opengraph_1200-2.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Corda</h5>
    <p class="card-text">R$ 19,99</p>
    <a href="#" class="btn btn-primary">Adicionar ao carrinho</a>
       </div>
      </div>
      
      
      <div class="card" style="width: 18rem;">
          
  <img src="https://vigiadepreco.com.br/blog/wp-content/uploads/2020/11/melhor-brinquedo-para-cachorro-hiperativo-2--950x500.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Ossinho</h5>
    <p class="card-text">R$ 7,99</p>
    <a href="#" class="btn btn-primary">Adicionar ao carrinho</a>
         </div>
       </div>
    </div>
       
       
       
       
       
        <div class="row">
        <div class="card" style="width: 18rem;">
            
  <img src="https://i3.wp.com/ae01.alicdn.com/kf/HTB1PnT9axD1gK0jSZFyq6AiOVXaI/1-conjunto-pet-c%C3%A3o-mordida-resistente-mastigar-corda-de-algod%C3%A3o-brinquedos-c%C3%A3es-dentes-bola-limpa-n%C3%A3o.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kit 4pet</h5>
    <p class="card-text">R$ 39,99</p>
    <a href="#" class="btn btn-primary">Adicionar ao carrinho</a>
        </div>
       </div>
       <a name="produtos"></a>
       <div class="card" style="width: 18rem;">
          
  <img src="https://image.made-in-china.com/202f0j10wfERNdrgZzoO/Dog-Cat-Pet-Chew-Toys-Durability-Vocalization-Bite-Dog-Toys-Pet-Accessories.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kit pelúcia</h5>
    <p class="card-text">R$ 39,99</p>
    <a href="#" class="btn btn-primary">Adicionar ao carrinho</a>
       </div>
      </div>
      
      
      <div class="card" style="width: 18rem;">
          
  <img src="https://ae01.alicdn.com/kf/HTB1eGlDaXzsK1Rjy1Xbq6xOaFXaU.jpg_q50.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kit bolinhas</h5>
    <p class="card-text">R$ 19,99</p>
    <a href="#" class="btn btn-primary">Adicionar ao carrinho</a>
         </div>
       </div>
    </div>    
        
        
        <hr><hr>
        <br><br><br>
        <hr><hr>
        <a name="agenda"></a>
        <h5>Agende o BANHO E TOSA do seu pet!</h5>
        
        <form action="reserva.php">
        <table>
        <tr>
        <td><input type=number name=dia min=1 max=31></td>
        <td><input type=month name=mentra></td>
        
        <td><label for="porte">  Porte: </label></td>

        <td><select id="porte" name=porte>
         <option value="pequeno">Pequeno</option>
         <option value="medio">Médio</option>
         <option value="grande">Grande</option>
         <option value="gigante">Gigante</option>
        </select></td>
        
        
        
       <td> <label for="horario">Manhã/Tarde:</label>

        <select id="horario" name=horario>
            <option value="manha">Manhã</option>
            <option value="tarde">Tarde</option>
  
        </select></td>
        
        <td><label for="nome">Seu nome:</label>
         <input type="text" id="nome" name="nome">
        </td>
        
        <td><input type=submit></td>
        
        </tr>
        </table>
        </form>
        <br><br>
        <hr><hr>
        <br><br>
        
      
     <a name="tosa"></a>  
      <h2>TABELA DE SERVIÇOS</h2>
        <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"><h5>Porte</h5></th>
      <th scope="col"><h5>Banho</h5></th>
      <th scope="col"><h5>Banho e Tosa</h5></th>
    </tr>
  </thead>
  
    <tr>
      <th scope="row">1</th>
      <td>Pequeno</td>
      <td>R$35,00</td>
      <td>R$60,00</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Médio</td>
      <td>R$45,00</td>
      <td>R$80,00</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Grande</td>
      <td>R$55,00</td>
      <td>R$100,00</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Gigante</td>
      <td>R$70,00</td>
      <td>R$120,00</td>
    </tr>
     </table>
     
     
     
     
     
     <div class="container">
    <div class="row">
    <div class="col">BLOG</div>
    <div class="col"> <a href='https://slmj.000webhostapp.com/trabalhohtml/usuario/consultablogUsuario.php'>CONSULTA</a></div>
    <div class="col"> <a href='https://slmj.000webhostapp.com/trabalhohtml/usuario/incluirblogUsuario.php'>INCLUSÃO</a></div>
    <div class="col"> <a href='https://slmj.000webhostapp.com/trabalhohtml/usuario/consultablogUsuario.php'>EXCLUSÃO</a></div>
    <div class="col"> <a href='https://slmj.000webhostapp.com/trabalhohtml/usuario/consultablogUsuario.php'>ALTERAÇÃO</a></div>
    </div>
     
   
    

   
   
                
<div class="row" >
    
     <?php
            include_once("servico/Bd.php");
            
            $bd = new Bd();
            
            $sql = "select * from blog";
            
            foreach ($bd->query($sql) as $row) {
               
               echo  '
                <div class="card mr-5 mb-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title">'.$row['titulo'].'</h5>
                    <p class="card-text">'.substr($row['corpo'],0,100).' ...</p>
                    <a href="#" class="card-link">Leia mais</a>
                  </div>
                </div>
               ';
               
            }
        
        ?>
   
   
   
   
   
   
   
        

	
	<br><br>
	
	
	  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>


</body>
</html>